package edu.umbc.cs.maple.utils;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** A collection of machine learning utility functions.
 * <p>
 * Copyright (c) 2008 Eric Eaton
 * <p>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 * 
 * @author Eric Eaton (EricEaton@umbc.edu) <br>
 *         University of Maryland Baltimore County
 * 
 * @version 0.1
 *
 */
public class MLUtils {
	
	/** Calculates the normalized the area between these two learning curves by the area between the baselineLearningCurve and
	 * a horizontal line at the bestPerformance.
	 * @param baselineLearningCurve
	 * @param targetLearningCurve
	 * @param bestPerformance
	 * @return the normalized area between the learning curves
	 */
	public static double normalizedAreaBetweenLearningCurves(Point2D[] baselineLearningCurve, Point2D[] targetLearningCurve, double bestPerformance) {
		// compute the area between the baseline and target curve
		double[] results = areaBetweenLearningCurves(baselineLearningCurve, targetLearningCurve);
		double areaBaselineToTarget = results[0];
		double startXcoord = results[1];
		double stopXcoord = results[2];
		
		// create the best performance curve for this range of x coordinates
		Point2D[] bestPerformanceLine = new Point2D[2];
		bestPerformanceLine[0] = new Point2D.Double(startXcoord, bestPerformance);
		bestPerformanceLine[1] = new Point2D.Double(stopXcoord, bestPerformance);
		
		// compute the area between the baseline and the best performance curve
		results = areaBetweenLearningCurves(baselineLearningCurve, bestPerformanceLine);
		double areaBaselineToBest = results[0];
		
		// normalize the area by the best area
		double normalizedArea = areaBaselineToTarget / areaBaselineToBest;
		return normalizedArea;
	}
	
	public static void main(String[] args) {
		Point2D[] baseline = new Point2D[] {
				new Point2D.Double(0,0.5),
				new Point2D.Double(10,0.5)
		};
		
		Point2D[] targetline = new Point2D[] {
				new Point2D.Double(0,0.5),
				new Point2D.Double(5,1),
				new Point2D.Double(10,0.5)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		System.out.println("Answer = 2.5");
		
		
		
		baseline = new Point2D[] {
				new Point2D.Double(0,0.5),
				new Point2D.Double(10,0.5)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0,1),
				new Point2D.Double(10,1)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		System.out.println("Answer = 5");
		
		
		
		baseline = new Point2D[] {
				new Point2D.Double(0,0.5),
				new Point2D.Double(10,0.5)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0,0),
				new Point2D.Double(10,1)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		System.out.println("Answer = 0");
		
		
		baseline = new Point2D[] {
				new Point2D.Double(0.25,0.5),
				new Point2D.Double(0.5,0.65),
				new Point2D.Double(0.75,0.70),
				new Point2D.Double(1,0.75)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0.25,0.45),
				new Point2D.Double(0.5,0.65),
				new Point2D.Double(0.75,0.75),
				new Point2D.Double(1,0.80)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		
		
		baseline = new Point2D[] {
				new Point2D.Double(0.25,0.5),
				new Point2D.Double(0.5,0.65),
				new Point2D.Double(0.75,0.70),
				new Point2D.Double(1,0.75)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0.25,0.45),
				new Point2D.Double(0.5,0.65),
				new Point2D.Double(0.75,0.75),
				new Point2D.Double(1,0.70)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		
		baseline = new Point2D[] {
				new Point2D.Double(0.25,0.5),
				new Point2D.Double(0.5,0.6),
				new Point2D.Double(0.75,0.4),
				new Point2D.Double(1,0.5)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0.25,0.5),
				new Point2D.Double(0.5,0.4),
				new Point2D.Double(0.75,0.6),
				new Point2D.Double(1,0.5)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		
		System.out.println("Answer ~= 0");
		
		baseline = new Point2D[] {
				new Point2D.Double(0.25,0.5),
				new Point2D.Double(0.5,0.65)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(0.25,0.45),
				new Point2D.Double(0.5,0.65)
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		
		
		baseline = new Point2D[] {
				new Point2D.Double(40.0,0.8125),
				new Point2D.Double(70.0,0.88125),
				new Point2D.Double(100.0,0.87875),
				new Point2D.Double(150.0,0.895),
				new Point2D.Double(200.0,0.92625)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(40.0,0.8425),
				new Point2D.Double(70.0,0.8575),
				new Point2D.Double(100.0,0.89125),
				new Point2D.Double(150.0,0.91),
				new Point2D.Double(200.0,0.9075),
		};
		
		areaBetweenLearningCurves(baseline, targetline);

		
		
		baseline = new Point2D[] {
				new Point2D.Double(40.0,0.915),
				new Point2D.Double(70.0,0.935),
				new Point2D.Double(100.0,0.91625),
				new Point2D.Double(150.0,0.94),
				new Point2D.Double(200.0,0.94625)
		};
		
		targetline = new Point2D[] {
				new Point2D.Double(40.0,0.925),
				new Point2D.Double(70.0,0.92625),
				new Point2D.Double(100.0,0.89875),
				new Point2D.Double(150.0,0.93),
				new Point2D.Double(200.0,0.95),
		};
		
		areaBetweenLearningCurves(baseline, targetline);
		System.out.println("Answer ~= -1.218800105");


	}

	
	/** Given two learning curves, determines the area between the two curves.
	 * This area has a sign based on the relationship between the baseline curve
	 * and the target curve.  If the target curve is below the baseline, the sign
	 * will be negative; otherwise, it will be positive.  If it is a mix of above
	 * and below, a negative sign would indicate that the target is more below
	 * the baseline than above it.
	 * 
	 * Note that the baseline and target learning curves can have different starting 
	 * and ending points from each other, and different points along the curves.
	 * @param baselineLearningCurve - the baseline learning curve vertices, in increasing order by x-coordinate
	 * @param targetLearningCurve - the target learning curve vertices, in increasing order by x-coordinate
	 * @return the area between the curves, the first x coordinate of this area, and the last x coordinate of this area.
	 */
	public static double[] areaBetweenLearningCurves(Point2D[] baselineLearningCurve, Point2D[] targetLearningCurve) {
		
		//// error check arguments
	
		// ensure that each curve has at least one point
		if (baselineLearningCurve == null || baselineLearningCurve.length < 1) {
			throw new IllegalArgumentException("baseline learning curve must have at least one point.");
		}
		if (targetLearningCurve == null || targetLearningCurve.length < 1) {
			throw new IllegalArgumentException("target learning curve must have at least one point.");
		}

		int numBaselinePts = baselineLearningCurve.length;
		int numTargetPts = targetLearningCurve.length;
		
		//// align the learning curves
		
		// determine the starting and ending x coordinates
		double startingXcoord = Math.max(baselineLearningCurve[0].getX(), targetLearningCurve[0].getX());
		double stoppingXcoord = Math.min(baselineLearningCurve[numBaselinePts-1].getX(), targetLearningCurve[numTargetPts-1].getX());
		// trim the two lines to the starting and stopping x coordinates
		Point2D[] croppedBaseline = cropLineX(baselineLearningCurve, startingXcoord, stoppingXcoord);
		Point2D[] croppedTarget = cropLineX(targetLearningCurve, startingXcoord, stoppingXcoord);
		
		
		//// ensure that each curve has the same x-coordinates, adding points where needed
		
		// determine the total set of x-coordinates
		Set<Double> xCoordsSet = new HashSet<Double>();
		for (Point2D p : croppedBaseline) {
			xCoordsSet.add(p.getX());
		}
		for (Point2D p : croppedTarget) {
			xCoordsSet.add(p.getX());
		}
		// form this set into a double[]
		double[] xCoords = JavaUtils.collectionToPrimitiveArray(xCoordsSet);
		java.util.Arrays.sort(xCoords);
		
		// check that each curve has all of these x-coordinates.
		// Only need to possibly add points when the lengths differ
		if (xCoords.length != croppedBaseline.length) {
			croppedBaseline = ensureCurveHasXCoordinates(croppedBaseline, xCoords);
		}
		if (xCoords.length != croppedTarget.length) {
			croppedTarget = ensureCurveHasXCoordinates(croppedTarget, xCoords);
		}
			
		
		//// assert that the number of points are equal for the intersection code
		if (croppedTarget.length != croppedBaseline.length) {
			throw new IllegalStateException("Critical error in MLUtils.areaBetweenLearningCurves():  baseline and target curves have unequal numbers of points, when they should have been made identical.");
		}
		
		
		//// add in points where the lines intersect
		
		// determine the intersections, which we can do by comparing pairs of line segments
		ArrayList<Point2D> intersections = new ArrayList<Point2D>();
		for (int i=0; i<croppedBaseline.length-1; i++) {
			Point2D baselinePt1 = croppedBaseline[i];
			Point2D baselinePt2 = croppedBaseline[i+1];
			Point2D targetPt1 = croppedTarget[i];
			Point2D targetPt2 = croppedTarget[i+1];
			
			// assert that the starting and stopping x coordinates are the same between line segments
			if (!(MathUtils.isApproxEqual(baselinePt1.getX(), targetPt1.getX()) && 
				  MathUtils.isApproxEqual(baselinePt2.getX(), targetPt2.getX()))) {
				throw new IllegalStateException("Critical error in MLUtils.areaBetweenLearningCurves():  baseline and target curve line segments do not match.  {"+baselinePt1+"-"+baselinePt2+"} & {"+targetPt1+"-"+targetPt2+"}");
			}
			//	System.out.println("Baseline and target curve line segments match.  ["+baselinePt1+"-"+baselinePt2+"] & ["+targetPt1+"-"+targetPt2+"]");

			// there can only be an intersection if the line segments cross
			if ((targetPt1.getY() > baselinePt1.getY() && targetPt2.getY() < baselinePt2.getY()) ||
				(targetPt1.getY() < baselinePt1.getY() && targetPt2.getY() > baselinePt2.getY())) {
				
				// determine the intersection
				Line2D baselineSegment = new Line2D.Double(baselinePt1,baselinePt2);
				Line2D targetSegment = new Line2D.Double(targetPt1, targetPt2);
				Point2D intersection = getIntersection(baselineSegment, targetSegment);
				
				// store the intersection, if it exists and is unique
				if (intersection != null) {
					// determine if the intersection is unique
					boolean intersectionUnique = true;
					for (Point2D p : intersections) {
						if (MathUtils.isApproxEqual(p.getX(), intersection.getX()) &&
							MathUtils.isApproxEqual(p.getY(), intersection.getY())) {
							intersectionUnique = false;  // only set to false if the points match
						}
					}
					if (intersectionUnique) {
						intersections.add(intersection);
					}
				}
			}
		}
		
		// add these as additional points
		Point2D[] finalBaseline = croppedBaseline;
		Point2D[] finalTarget = croppedTarget;
		if (intersections.size() > 0) {
			finalBaseline = appendSortX(croppedBaseline, (Point2D[]) intersections.toArray(new Point2D[0]));
			finalTarget = appendSortX(croppedTarget, (Point2D[]) intersections.toArray(new Point2D[0]));
		}
			
		//// determine the area, tracing along the baseline first
		Point2D[] allPoints = new Point2D[finalBaseline.length+finalTarget.length];
		System.arraycopy(finalBaseline,0,allPoints,0,finalBaseline.length);
		// we have to reverse the target line, since we'll be going backwards over its points
		System.arraycopy(JavaUtils.arrayReverse(finalTarget),0,allPoints,finalBaseline.length, finalTarget.length);
		double area = computePolygonArea(allPoints);
		
		/*
		// print out the two curves and the area
		System.out.print("Computed Area: "+area+"  Augmented Baseline: [");
		for (Point2D p : finalBaseline) {
			System.out.print("("+p.getX()+","+p.getY()+") ");
		}
		System.out.print("]  Augmented Transfer: [");
		for (Point2D p : finalTarget) {
			System.out.print("("+p.getX()+","+p.getY()+") ");
		}
		System.out.println("]");
*/
		return new double[] {area, startingXcoord, stoppingXcoord};
		
	}
	
	/** Ensures that the given curve contains all of the specified x-coordinates.
	 * @param curve a curve specified by a set of points in sorted order by x-coordinate
	 * @param xCoords a set of x-coordinates, sorted in increasing order
	 * @return a curve containing all of the original points and any missing x-coordinates
	 */
	public static Point2D[] ensureCurveHasXCoordinates (Point2D[] curve, double[] xCoords) {
		ArrayList<Point2D> ptsToAdd = new ArrayList<Point2D>();
		
		double curveStartX = curve[0].getX();
		double curveEndX = curve[curve.length-1].getX();

		int curveIdx = 1;  // can start at 1, since we're discarding xCoord <= curve[0]
		for (double xCoord : xCoords) {
			
			// discard points before or after the curve's domain
			if (xCoord <= curveStartX)
				continue; // next xCoord
			if (xCoord >= curveEndX)
				break;  // all other xCoords will be after the domain too, since xCoords is sorted
				
			// loop through the curve until xCoord <= curve[curveIdx]
			while (curve[curveIdx].getX() < xCoord) { 
				curveIdx++;
			} 
			
			// test whether this xCoord is already in the curve
			if (curve[curveIdx].getX() == xCoord) {
				curveIdx++;
				continue; // next xCoord, since this one is already in the curve
			}
			
			// at this point, curve[idx-1] < xCoord < curve[idx], so we can insert the new point
			Point2D newPt = MLUtils.interpolate(curve[curveIdx-1], curve[curveIdx], xCoord);
			ptsToAdd.add(newPt);
			
			// do not advance curveIdx, since there may be other xCoords such that
			// curve[idx-1] < xCoord < curve[idx]
		}

		// add these points into the curve and return it
		if (ptsToAdd.size() > 0) {
			return appendSortX(curve, (Point2D[]) ptsToAdd.toArray(new Point2D[0]));
		} else {
			return curve;
		}
	}
	
	
	/** Computes the area of the specified polygon.
	 * @param pts the vertices specifying the polygon.   
	 * @return the area of the specified polygon.
	 */
	public static double computePolygonArea (Point2D[] pts) {
	    int n = pts.length;
		
	    double area = 0.0;
	    for (int i = 0; i < n-1; i++) {
	      area += (pts[i].getX() * pts[i+1].getY()) - (pts[i+1].getX() * pts[i].getY());
	    }
	    
	    area += (pts[n-1].getX() * pts[0].getY()) - (pts[0].getX() * pts[n-1].getY());  
	    area *= 0.5;

	    return area;
	}
	

	/** Computes the intersection between two lines. The calculated point is approximate, 
	 * since integers are used. If you need a more precise result, use doubles everywhere.
	 * Modified from original version (by Alexander Hristov) by Eric Eaton. 
	 * (c) 2007 Alexander Hristov. Use Freely (LGPL license). http://www.ahristov.com
	 *
	 * @param lineA the first line
	 * @param lineB the second line
	 * @return point where the segments intersect, or null if they don't
	 */
	public static Point2D intersection(Line2D lineA, Line2D lineB) {
		
		Point2D lineAPt1 = lineA.getP1();
		Point2D lineAPt2 = lineA.getP2();
		Point2D lineBPt1 = lineB.getP1();
		Point2D lineBPt2 = lineB.getP2();
		
		double x1 = lineAPt1.getX();
		double y1 = lineAPt1.getY();
		double x2 = lineAPt2.getX();
		double y2 = lineAPt2.getY(); 
		double x3 = lineBPt1.getX();
		double y3 = lineBPt1.getY();
		double x4 = lineBPt2.getX();
		double y4 = lineBPt2.getY();
		
		double d = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
		if (d == 0) return null;
    
		double xi = ((x3-x4)*(x1*y2-y1*x2)-(x1-x2)*(x3*y4-y3*x4))/d;
		double yi = ((y3-y4)*(x1*y2-y1*x2)-(y1-y2)*(x3*y4-y3*x4))/d;
    
		return new Point2D.Double(xi,yi);
	}
	/** Computes the intersection between two lines.
	 * Modified slightly from original version 
	 * (http://blog.persistent.info/2004/03/java-lineline-intersections.html).  
	 * @param lineA the first line
	 * @param lineB the second line
	 * @return point where the segments intersect, or null if they don't
	 */
	static Point2D getIntersection(Line2D lineA, Line2D lineB) {
		
		if (true)
			return getIntersection2(lineA, lineB);
		
		if (!lineA.intersectsLine(lineB))
			return null;

		double x1 = lineA.getX1(), y1 = lineA.getY1(), x2 = lineA.getX2(), y2 = lineA.getY2(), x3 = lineB.getX1(), y3 = lineB.getY1(), x4 = lineB.getX2(), y4 = lineB.getY2();

		double x = det(det(x1, y1, x2, y2), x1 - x2, det(x3, y3, x4, y4), x3 - x4) / det(x1 - x2, y1 - y2, x3 - x4, y3 - y4);
		double y = det(det(x1, y1, x2, y2), y1 - y2, det(x3, y3, x4, y4), y3 - y4) / det(x1 - x2, y1 - y2, x3 - x4, y3 - y4);

		if (Double.isNaN(x) || Double.isNaN(y)) {
			System.err.println ("getIntersection():  cannot compute intersection but java says that one still exists.  Might be vertical or horizontal line case.  Need to fix.");
			return null;
		}
		return new Point2D.Double(x,y);
	}


	static double det(double a, double b, double c, double d) {
		return a * d - b * c;
	}
	
	/** Takes a line defined in point form ((x1,y1), (x2,y2)) and converts it to 
	 * standard form Ax + By = C.
	 * 
	 * @param line the line
	 * @return an array [A, B, C] representing the parameter values of the standard form.
	 */
	static double[] linePointToStandardForm(Line2D line) {
		double x1 = line.getX1(), y1 = line.getY1(), x2 = line.getX2(), y2 = line.getY2();
		double A = y2-y1;
		double B = x1-x2;
		double C = A*x1+B*y1;
		return new double[] {A,B,C};
	}
	
	/** Computes the intersection between two lines. 
	 * @param lineA the first line
	 * @param lineB the second line
	 * @return point where the segments intersect, or null if they don't
	 */
	static Point2D getIntersection2(Line2D line1, Line2D line2) {

		double[] values1 = linePointToStandardForm(line1);
		double A1 = values1[0];
		double B1 = values1[1];
		double C1 = values1[2];
		
		double[] values2 = linePointToStandardForm(line2);
		double A2 = values2[0];
		double B2 = values2[1];
		double C2 = values2[2];
		
		// compute the determinant
		double det = A1*B2 - A2*B1;
		
		// return null if the lines do not intersect
		if(det == 0){
			return null;
		}
		
		// compute the intersection
		double x = (B2*C1 - B1*C2) / det;
		double y = (A1*C2 - A2*C1) / det;
		Point2D intersectionPt = new Point2D.Double(x,y);
		
		// check that the intersection is inside both line segments
		if (!isPointOnLine(line1, intersectionPt) || !isPointOnLine(line2, intersectionPt))
			return null;
		
		return intersectionPt;
	}
	
	/** Determines whether a given point is on a line.
	 * @param line
	 * @param point
	 * @return whether the specified point is on the line
	 */
	public static boolean isPointOnLine(Line2D line, Point2D point) {
		double x1 = line.getX1(), y1 = line.getY1(), x2 = line.getX2(), y2 = line.getY2();
		double x = point.getX(), y = point.getY();
		// test that the point is actually in the range
		if (Math.min(x1,x2) <= x && x <= Math.max(x1, x2) &&
		    Math.min(y1,y2) <= y && y <= Math.max(y1, y2)) {
			// test that the point falls on the line
			double[] values1 = linePointToStandardForm(line);
			double A = values1[0];
			double B = values1[1];
			double C = values1[2];
			double Cprime = A*x + B*y;
			if (MathUtils.isApproxEqual(C, Cprime)) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

		

	
	/** Combine two sorted vectors of points into one vector of sorted points.
	 * @param pts1
	 * @param pts2
	 * @return the vector of sorted points from pts1 and pts2
	 */
	public static Point2D[] appendSortX(Point2D[] pts1, Point2D[] pts2) {
		
		ArrayList<Point2D> pts = new ArrayList<Point2D>();
		
		for (int pts1Idx=0, pts2Idx=0; pts1Idx < pts1.length || pts2Idx < pts2.length; ) {
			Point2D pt1 = (pts1Idx < pts1.length) ? pts1[pts1Idx] : null;
			Point2D pt2 = (pts2Idx < pts2.length) ? pts2[pts2Idx] : null;
			if (pt1 == null) {
				pts.add(pt2);
				pts2Idx++;
			} else if (pt2 == null) {
				pts.add(pt1);
				pts1Idx++;
			} else if (pt1.getX() < pt2.getX()) {
				pts.add(pt1);
				pts1Idx++;
			} else if (pt1.getX() > pt2.getX()) {
				pts.add(pt2);
				pts2Idx++;
			} else {  // x's are the same
				if (!MathUtils.isApproxEqual(pt1.getY(), pt2.getY(), 10E-10)) {
					throw new IllegalStateException("Error:  two points have the same x's but different y's: "+pt1+"; "+pt2+".");
				}
				pts.add(pt1);
				pts1Idx++;
				pts2Idx++;
			}
		}
		
		return (Point2D[]) pts.toArray(new Point2D[0]);
	}
	
	
	/** Crops a line to the given x-coordinates.
	 * @param line
	 * @param startingXcoord
	 * @param stoppingXcoord
	 * @return the line cropped to the specified x-coordinates 
	 */
	public static Point2D[] cropLineX(Point2D[] line, double startingXcoord, double stoppingXcoord) {
		
		// ensure that the line has at least one point
		if (line.length < 1) {
			throw new IllegalArgumentException("The line must contain at least one point.");
		}
		
		int maxIdx = line.length-1;
		
		// determine the actual starting and stopping coordinates
		double startX = Math.max(startingXcoord, line[0].getX());
		double stopX = Math.min(stoppingXcoord, line[maxIdx].getX());
		
		// determine the index of each starting and stopping point;
		// these are the indices of the first vertices inside the cutoff
		// from the original set of vertices.
		int startXidx = 0;
		while (startXidx < maxIdx && line[startXidx].getX() <= startX) {
			startXidx++;
		}
		int stopXidx = maxIdx;
		while (stopXidx > 0 && line[stopXidx].getX() >= stopX) {
			stopXidx--;
		}
		
		// determine the new starting and stopping points
		Point2D firstPt = interpolate(line[startXidx-1], line[startXidx], startX);
		Point2D lastPt = interpolate(line[stopXidx], line[stopXidx+1], stopX);
		
		// generate the new line
		Point2D[] croppedLine = new Point2D[stopXidx - startXidx + 3]; // leaving room for the 2 end points
		// copy all interior points verbatim from the original line
		for (int origIdx = startXidx, newIdx = 1; origIdx <= stopXidx; origIdx++, newIdx++) {
			croppedLine[newIdx] = line[origIdx];
		}
		// add in the new endpoints
		croppedLine[0] = firstPt;
		croppedLine[croppedLine.length-1] = lastPt;
		
		return croppedLine;
		
	}

	
	/** Does linear interpolation at x of the line from pt1 to pt2.
	 * @param pt1 one endpoint of the line.
	 * @param pt2 another endpoint of the line.
	 * @param x the x-coordinate of the interpolated point.
	 * @return the desired interpolated point.
	 */
	public static Point2D interpolate(Point2D pt1, Point2D pt2, double x) {
		double slope = (pt2.getY() - pt1.getY()) / (pt2.getX() - pt1.getX());
		double y = pt1.getY() + (x - pt1.getX()) * slope;
		return new Point2D.Double(x,y);
	}
	
	/** Interpolates the given x onto the line of points.
	 * @param points
	 * @param x
	 * @return x interpolated onto the line defined by the points
	 */
	public static Point2D interpolate(Point2D[] points, double x) {
		// determine the two point boundaries for the line segment
		for (int i=0; i<points.length-1; i++) {
			Point2D pt1 = points[i];
			Point2D pt2 = points[i+1];
			if (x == pt1.getX())
				return new Point2D.Double(pt1.getX(), pt1.getY());
			else if (x < pt2.getX())
				return interpolate(pt1, pt2, x);
		}
		
		// if we reach here, then x >= the last point
		Point2D pt1 = points[points.length-2];
		Point2D pt2 = points[points.length-1];
		if (x == pt2.getX())
			return new Point2D.Double(pt2.getX(), pt2.getY());
		else
			return interpolate(pt1, pt2, x);
	}
	
	/** Determines the minimum y-coordinate for the set of points.
	 * @param points
	 * @return the minimum y-coordinate of the points
	 */
	public static double minY(Point2D[] points) {
		double minY = Double.MAX_VALUE;
		for (Point2D point : points) {
			if (point.getY() < minY) {
				minY = point.getY();
			}
		}
		return minY;
	}
	
	/** Determines the maximum y-coordinate for the set of points.
	 * @param points
	 * @return the maximum y-coordinate of the points
	 */
	public static double maxY(Point2D[] points) {
		double maxY = Double.MIN_VALUE;
		for (Point2D point : points) {
			if (point.getY() > maxY) {
				maxY = point.getY();
			}
		}
		return maxY;
	}

}
