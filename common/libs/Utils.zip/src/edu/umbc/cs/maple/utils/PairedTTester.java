package edu.umbc.cs.maple.utils;

import java.util.ArrayList;

import org.apache.commons.math.MathException;
import org.apache.commons.math.stat.inference.TTestImpl;

/** A class to perform a statistical paired T-test on a set of data.
 * <p>
 * Copyright (c) 2008 Eric Eaton
 * <p>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 * 
 * @author Eric Eaton (EricEaton@umbc.edu) <br>
 *         University of Maryland Baltimore County
 * 
 * @version 0.1
 *
 */
public class PairedTTester extends TTestImpl {
	
	ArrayList<Double> m_samples1 = new ArrayList<Double>();
	ArrayList<Double> m_samples2 = new ArrayList<Double>();
	
	
	/** Adds the first number of a pair of values.  
	 * Each pair must be added in the same order using a matched pair of
	 * addSample1() and addSample2() function calls.
	 * @param value
	 */
	public void addSample1(double value) {
		m_samples1.add(value);
	}
	
	/** Adds the second number of a pair of values.
	 * Each pair must be added in the same order using a matched pair of
	 * addSample1() and addSample2() function calls.
	 * @param value
	 */
	public void addSample2(double value) {
		m_samples2.add(value);
	}
	
	/** Adds a matched pair of values.
	 * @param sample1value
	 * @param sample2value
	 */
	public void addSample(double sample1value, double sample2value) {
		m_samples1.add(sample1value);
		m_samples2.add(sample2value);
	}
	
	/** Returns the significance level of a paired t-test of the two samples
	 * @return the significance level of the paired t-test of the two samples
	 * @throws MathException
	 */
	public double pairedTTest() throws MathException {
		double[] samples1 = JavaUtils.collectionToPrimitiveArray(m_samples1);
		double[] samples2 = JavaUtils.collectionToPrimitiveArray(m_samples2);
		
		if (samples1.length != samples2.length)
			throw new MathException("The samples are different lengths.");
		
		return pairedTTest(samples1, samples2);
	}

}
