package edu.umbc.cs.maple.utils;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;


/** Various utility functions for Java.
 * <p>
 * Copyright (c) 2008 Eric Eaton
 * <p>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 * 
 * @author Eric Eaton (EricEaton@umbc.edu) <br>
 *         University of Maryland Baltimore County
 * 
 * @version 0.1
 *
 */
public class JavaUtils {
	
	
	/** Appends an element to an array.
	 * @param <T> the generic type of the array.
	 * @param objs the array.
	 * @param newObj the object to append the the array.
	 * @return the array with the specified element appended
	 */
	public static <T> T[] arrayAppend(T[] objs, T newObj) {
		T[] newObjs = (T[]) Array.newInstance(newObj.getClass(), objs.length+1);
		System.arraycopy(objs,0,newObjs,0,objs.length);
		newObjs[objs.length] = newObj;
		return (T[]) newObjs;
	}
	
	/** Appends an element to an array.
	 * @param objs the array.
	 * @param newObj the object to append the the array.
	 * @return the array with the specified element appended
	 */
	public static int[] arrayAppend(int[] objs, int newObj) {
		int[] newObjs = new int[objs.length + 1];
		System.arraycopy(objs,0,newObjs,0,objs.length);
		newObjs[objs.length] = newObj;
		return newObjs;
	}
	
	
	
	/** Copy the given array.
	 * @param <T> the generic type of the array.
	 * @param objs the array.
	 * @return a copy of the array, <code>null</code> if the array is null.
	 */
	public static <T> T[] arrayCopy(T[] objs) {
		if (objs == null) return null;
		Object[] copy = new Object[objs.length];
		System.arraycopy(objs, 0, copy, 0, objs.length);
		return (T[]) copy;
	}
	
	/** Copy the given array.
	 * @param objs the array.
	 * @return a copy of the array, <code>null</code> if the array is null.
	 */
	public static int[] arrayCopy(int[] objs) {
		if (objs == null) return null;
		int[] copy = new int[objs.length];
		System.arraycopy(objs, 0, copy, 0, objs.length);
		return copy;
	}
	
	/** Copy the given array.
	 * @param objs the array.
	 * @return a copy of the array, <code>null</code> if the array is null.
	 */
	public static double[] arrayCopy(double[] objs) {
		if (objs == null) return null;
		double[] copy = new double[objs.length];
		System.arraycopy(objs, 0, copy, 0, objs.length);
		return copy;
	}

	
	
	/** Delete the specified element from the array.
	 * @param <T> the generic type of the array.
	 * @param objs the array.
	 * @param indexToDelete the index to delete from the array.
	 * @return the array with the specified element deleted.
	 */
	public static <T> T[] arrayDelete(T[] objs, int indexToDelete) {
		
		if (indexToDelete < 0 || indexToDelete >= objs.length) {
			throw new IllegalArgumentException("indexToDelete is out of range [0,"+(objs.length-1)+"].");
		}
		
		T[] newObjs = (T[]) Array.newInstance(objs[0].getClass(), objs.length-1);
		if (indexToDelete != 0) {
			System.arraycopy(objs, 0, newObjs, 0, indexToDelete);
		}
		// add conditional on next statement if (indexToDelete != objs.length-1) if there's a problem
		System.arraycopy(objs, indexToDelete+1, newObjs, indexToDelete, objs.length-indexToDelete-1);
		return newObjs;
	}
	
	
	/** Reverses the given array.
	 * @param <T> the generic type of the array.
	 * @param array the array.
	 * @return the array with the elements in reverse order
	 */
	public static <T> T[] arrayReverse(T[] array) {
		Object[] reverseArray = new Object[array.length];
		for (int i=0; i<array.length; i++) {
			reverseArray[array.length-1-i] = array[i];
		}
		return (T[]) reverseArray;
	}
	
	
	public static double[] collectionToPrimitiveArray(Collection<Double> collection) {
		double[] array = new double[collection.size()];
		int i=0;
		for (double d : collection) {
			array[i++] = d;
		}
		return array;
	}
	
	public static int[] collectionToPrimitiveArray(Collection<Integer> collection) {
		int[] array = new int[collection.size()];
		int i=0;
		for (int d : collection) {
			array[i++] = d;
		}
		return array;
	}
	
	public static String arrayToString(double[] v) { return arrayToString(v,null); }
	
	public static String arrayToString(double[] v, DecimalFormat df) {
		String str = "";
		for (int i=0; i<v.length; i++) {
			str += ((i!=0) ? "," : "") + ((df == null) ? v[i] : df.format(v[i]));
		}
		return str;
	}
	
	public static String arrayToString(String[] v) {
		String str = "";
		for (int i=0; i<v.length; i++) {
			str += ((i!=0) ? "," : "") + v[i];
		}
		return str;
	}

	
	public static DecimalFormat format1DecimalPlace = new DecimalFormat("0.0");
	public static DecimalFormat format2DecimalPlaces = new DecimalFormat("0.00");
	public static DecimalFormat format3DecimalPlaces = new DecimalFormat("0.000");
	public static DecimalFormat format4DecimalPlaces = new DecimalFormat("0.0000");
	
	/**
	 * Opens a file and generates an array of strings. Each string in the array is a non-comment, non-blank line from
	 * the file
	 * @param filename - the name of the file to open
	 * @return - an array strings representing the meaningful lines in the file
	 */
	public static String[] parseFileToStringArray(String filename) {
		ArrayList<String> lines = new ArrayList<String>();
		try {
			FileReader inFile = new FileReader(filename);
			BufferedReader reader = new BufferedReader(inFile);
			while (reader.ready()) {
				String line = reader.readLine();
				// skip line if is a comment or blank
				if (line.startsWith("%") || line.trim().length() == 0)
					continue;
				// Read in a line from the config file.
				lines.add(line);
			}
		} catch (java.io.IOException e) {
			//if (!(new File(filename)).exists())
			//	System.err.println("File \""+filename+"\" does not exist.");
			//else
				System.err.println("Could not process file \"" + filename + "\": " + e.getMessage());
			System.exit(1);
		}
		return (String[]) lines.toArray(new String[0]);
	}
	
	// Taken from http://www.java-tips.org/java-se-tips/java.io/reading-a-file-into-a-byte-array.html
	public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    }

	// Taken from http://forum.java.sun.com/thread.jspa?threadID=558981&tstart=240
	public static BufferedImage getBufferedImage(Image img) {
		// if the image is already a BufferedImage, cast and return it
		if((img instanceof BufferedImage)) {
			return (BufferedImage)img;
		}
		// otherwise, create a new BufferedImage and draw the original image on it
		int w = img.getWidth(null);
		int h = img.getHeight(null);
		BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2d = bi.createGraphics();
		g2d.drawImage(img, 0, 0, w, h, null);
		g2d.dispose();
		return bi;
	}
	
	public static long totalMemoryMB(){
		//System.gc();  OPTIMIZATION - System.gc() takes a long time
		/*try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("interupted");
		}*/
		return ( Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory() ) >> 20;
	}

}
