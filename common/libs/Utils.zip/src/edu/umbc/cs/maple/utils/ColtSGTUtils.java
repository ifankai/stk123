package edu.umbc.cs.maple.utils;

import cern.colt.matrix.DoubleFactory2D;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.doublealgo.Formatter;
import cern.colt.matrix.linalg.EigenvalueDecomposition;

/** Various utility functions for Spectral Graph Theory using the COLT matrix library.
 * <p>
 * Copyright (c) 2008 Eric Eaton
 * <p>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 * 
 * @author Eric Eaton (EricEaton@umbc.edu) <br>
 *         University of Maryland Baltimore County
 * 
 * @version 0.1
 *
 */
public class ColtSGTUtils {
	
	public enum LaplacianType { COMBINATORIAL, NORMALIZED }
	
	
	
	/** Computes the Laplacian matrix for a weighted adjacency matrix A.
	 * Automatically detects whether the adjacency matrix is directed or undirected.
	 *
	 * @param adjacencyMatrix the adjacency matrix
	 * @param laplacianType whether to use the normalized or combinatorial form of the Laplacian
	 */
	public static DoubleMatrix2D weightedAdjacencyToLaplacian(DoubleMatrix2D adjacencyMatrix, LaplacianType laplacianType) {
		// an undirected graph must have a symmetric adjacency matrix		
		if (ColtUtils.isSymmetric(adjacencyMatrix))
			return undirectedWeightedAdjacencyToLaplacian(adjacencyMatrix, laplacianType);
		else
			return directedWeightedAdjacencyToLaplacian(adjacencyMatrix, laplacianType);
	}
	

		

	/** Computes the Laplacian matrix for an undirected weighted adjacency matrix A.
	 * Coded from Section 1.4 of Chung's Spectral Graph Theory
	 *
	 * @param adjacencyMatrix the adjacency matrix
	 * @param laplacianType whether to use the normalized or combinatorial form of the Laplacian
	 */
	public static DoubleMatrix2D undirectedWeightedAdjacencyToLaplacian(DoubleMatrix2D adjacencyMatrix, LaplacianType laplacianType) {
		
		int numRows = adjacencyMatrix.rows();
		int numCols = adjacencyMatrix.columns();
		
		if (numRows != numCols) {
			throw new IllegalArgumentException("adjacencyMatrix must be square.");
		}
		
		// precompute the row sums
		DoubleMatrix2D D = DoubleFactory2D.sparse.diagonal(ColtUtils.rowsum(adjacencyMatrix));

		// combinatorial Laplacian
		DoubleMatrix2D Laplacian = ColtUtils.minus(D,adjacencyMatrix);
		
		// normalize the Laplacian if desired
		if (laplacianType == LaplacianType.NORMALIZED) {
			// L = D^-0.5 L D^-0.5
			DoubleMatrix2D Dnegsqrt = ColtUtils.diagonalPow(D, -0.5);
			Laplacian = ColtUtils.mult(Dnegsqrt, ColtUtils.mult(Laplacian, Dnegsqrt));
		}
		
		return Laplacian;
	}
	
	
	
	/** Computes the Laplacian matrix for a directed weighted adjacency matrix A.
	 *
	 * @param adjacencyMatrix the adjacency matrix
	 * @param laplacianType whether to use the normalized or combinatorial form of the Laplacian
	 */
	public static DoubleMatrix2D directedWeightedAdjacencyToLaplacian(DoubleMatrix2D adjacencyMatrix, LaplacianType laplacianType) {
		
		int numRows = adjacencyMatrix.rows();
		int numCols = adjacencyMatrix.columns();

		
		if (numRows != numCols) {
			throw new IllegalArgumentException("adjacencyMatrix must be square.");
		}
		
		// precompute the row sums
		DoubleMatrix1D rowsums = ColtUtils.rowsum(adjacencyMatrix);
		DoubleMatrix2D D = DoubleFactory2D.sparse.diagonal(rowsums);
		
		// automatically add in uniform out edges to all other nodes from a sink in A
		adjacencyMatrix = adjacencyMatrix.copy();
		double defaultTransitionProbability = 1.0 / numRows;
		for (int i=0; i<numRows; i++) {
			if (rowsums.get(i) == 0) {
				adjacencyMatrix.viewRow(i).assign(defaultTransitionProbability);
				rowsums.set(i, 1);
				D.set(i,i,1);
			}
		}
		
		DoubleMatrix2D P = ColtUtils.mult(ColtUtils.inverse(D), adjacencyMatrix);
		
		
		// compute the Perron vector of P
		
		// compute the teleport matrix
		// TODO: according to Jeff Johns and Mahadevan (ICML 2007), we don't need to explicitly
		// compute the Pteleport matrix and can do it in O(n) instead
		double eta = 0.99;
		double probTeleport = (1-eta)/numRows;
		DoubleMatrix2D Pscaled = ColtUtils.scale(P,eta);

		DoubleMatrix2D psi = DoubleFactory2D.sparse.random(numRows,1);
		psi = ColtUtils.normalize(psi); //normalize to sum to 1

		// loop until convergence
		boolean converged = false;
		int numIterations = 0;
		while (!converged) {
		    
			// psi_new = [psi' * Pscaled]' + (1-eta)/numRows * (sum_i psi_i) * 1
			// psi' * Pscaled 
			DoubleMatrix2D psi_new = ColtUtils.transpose(ColtUtils.mult(ColtUtils.transpose(psi), Pscaled));
			// (1-eta)/numRows * (sum_i psi_i) * 1
			DoubleMatrix2D psi_teleport = psi.like(psi.rows(),1).assign(probTeleport * ColtUtils.sum(psi));
			psi_new = ColtUtils.plusEquals(psi_new, psi_teleport);
		    psi_new = ColtUtils.normalize(psi_new);
		    
		    // test for convergence
		    double norm = ColtUtils.normF(ColtUtils.minus(psi,psi_new));
		    if (norm < 1e-8) {
		        converged = true;
		    }
	   	  //  System.out.println(norm);
		    psi = psi_new;
		    
		    // test for max number of iterations
		    numIterations++;
		    if (numIterations > 500) {
		        converged = true;
		        System.err.println("Power method exceeded maximum number of iterations.  Results may be inaccurate.  Current norm:  " + norm);
		    }
		}
		
		// form the matrix phi with the Perron vector as the diagonal
		DoubleMatrix2D phi = DoubleFactory2D.sparse.diagonal(ColtUtils.to1D(psi));
		
		
		// precompute the conjugate transpose of P, which is just P.transpose() in our case
		DoubleMatrix2D PconjugateTranspose = ColtUtils.transpose(P);

		
		// compute the Laplacian
		DoubleMatrix2D Laplacian = null;
		
		switch (laplacianType) {
	
		case NORMALIZED:
			// compute the square root and negative square root of phi;
			// since phi is diagonal, this is simply the powers of the diagonals
			DoubleMatrix2D phiSquareRoot = DoubleFactory2D.sparse.make(numRows, numCols);
			DoubleMatrix2D phiNegSquareRoot = DoubleFactory2D.sparse.make(numRows, numCols);
			
			phiSquareRoot = ColtUtils.diagonalPow(phi,0.5);
			phiNegSquareRoot = ColtUtils.diagonalPow(phi,-0.5);
			
			// \Phi^{1/2} P \Phi^{-1/2}
			DoubleMatrix2D temp1 = ColtUtils.mult(phiSquareRoot,ColtUtils.mult(P,phiNegSquareRoot));
			// \Phi^{-1/2} P^* \Phi^{1/2}
			DoubleMatrix2D temp2 = ColtUtils.mult(phiNegSquareRoot,ColtUtils.mult(PconjugateTranspose,phiSquareRoot));
			// \frac{\Phi^{1/2} P \Phi^{-1/2} + \Phi^{-1/2} P^* \Phi^{1/2}}{2}
			DoubleMatrix2D temp3 = ColtUtils.scale(ColtUtils.plus(temp1,temp2),0.5);
			// I - \frac{\Phi^{1/2} P \Phi^{-1/2} + \Phi^{-1/2} P^* \Phi^{1/2}}{2}
			Laplacian = ColtUtils.minus(ColtUtils.identity(numRows), temp3);
			break;

		case COMBINATORIAL:
			// \Phi P
			DoubleMatrix2D tempA = ColtUtils.mult(phi,P);
			// P^* \Phi
			DoubleMatrix2D tempB = ColtUtils.mult(PconjugateTranspose,phi);
			// \frac{\Phi P +  P^* \Phi}{2}
			DoubleMatrix2D tempC = ColtUtils.scale(ColtUtils.plus(tempA,tempB),0.5);
			// \Phi - \frac{\Phi P +  P^* \Phi}{2}
			Laplacian = ColtUtils.minus(phi,tempC);
			break;
		}

		return Laplacian;
	}
	
	
	
	
	public enum KeyEigenvalues {LARGEST, SMALLEST}
	
	/** Computes the specified resolution of matrix A.
	 * @param A the matrix
	 * @param resolution the resolution
	 * @param keyEigenvalues specifies whether the top LARGEST or SMALLEST 
	 * 	eigenvalues should be taken.  LARGEST should be the choice for most
	 *  applications; SMALLEST should be the choice for eigenvectors of the
	 *  graph Laplacian.
	 * @return three matrices M[3]
	 *   M[0]:  Ak, A at the specified resolution
	 *   M[1]:  Qk, the eigenvectors used to compose Ak
	 *   M[2]:  Lk, the eigenvalues used to compose Ak
	 */
	public static DoubleMatrix2D[] resolution(DoubleMatrix2D A, int resolution, KeyEigenvalues keyEigenvalues) {
	
		
		// perform the eigendecomposition
		EigenvalueDecomposition eig = new EigenvalueDecomposition(A);
		DoubleMatrix2D Q = eig.getV();
		DoubleMatrix2D L = eig.getD();
		
		int n = Q.columns();
		DoubleMatrix2D Lk=null, Qk=null;
		
		if (resolution > n) {
			throw new IllegalArgumentException("Max resolution available is: "+n+".");
		}
		
		
		switch (keyEigenvalues) {
		
		case SMALLEST:
			// keep only the smallest eigenvalues (zero the rest)
			// Matlab code:
			// L((resolution+1):end, (resolution+1):end) = 0;
	        // Lk = L(1:resolution, 1:resolution);
	        // Qk = Q(:, 1:resolution);
			L = L.copy();
			L.viewPart(resolution+1, n, resolution+1, n).assign(0);
			Lk = L.viewPart(0,resolution-1,0,resolution-1);
			Qk = Q.viewPart(0,n-1,0,resolution-1);
			break;
			
		case LARGEST:
			// keep only the largest eigenvalues (zero the rest)
			// Matlab code:
			// L(1:(n-resolution), 1:(n-resolution)) = 0;
	        // Lk = L((n-resolution+1):end, (n-resolution+1):end);
	        // Qk = Q(:, (n-resolution+1):end);
			int stop = n-resolution;
			L = L.copy();
			L.viewPart(0, stop, 0, stop).assign(0);
			Lk = L.viewPart(stop,n-1,stop,n-1);
			Qk = Q.viewPart(0,n-1,stop,n-1);
			break;
		}
		
	    // recompose the matrix  (Q * L * Q')
		DoubleMatrix2D Ak = ColtUtils.mult(ColtUtils.mult(Q,L), ColtUtils.transpose(Q));
	    
		DoubleMatrix2D[] struct = new DoubleMatrix2D[3];
	    struct[0] = Ak;
	    struct[1] = Qk;
	    struct[2] = Lk;
	    return struct;
	   
	}
	
	
	
	/** Computes the specified resolution of a function on a graph.
	 * @param graphLaplacian the graph Laplacian
	 * @param f the function values on the vertices of the graph
	 * @param resolution the resolution
	 * @return three matrices M[3]
	 *   M[0]:  fk, f at the specified resolution on the graph
	 *   M[1]:  Qk, the eigenfunctions of the graph Laplacian used in the computation
	 *   M[2]:  Lk, the eigenvalues of the graph Laplacian used in the computation
	 */
	public static DoubleMatrix2D[] resolutionGraphFunction(DoubleMatrix2D graphLaplacian, DoubleMatrix2D f, int resolution) {
	
	    // perform the eigendecomposition of the Laplacian
		DoubleMatrix2D[] eigLaplacian = resolution(graphLaplacian, resolution, KeyEigenvalues.SMALLEST);
		DoubleMatrix2D Qk = eigLaplacian[1];
		DoubleMatrix2D Lk = eigLaplacian[2];
		DoubleMatrix2D fk = projectFunctionToBasis(Qk,f);

		DoubleMatrix2D[] struct = new DoubleMatrix2D[3];
	    struct[0] = fk;
	    struct[1] = Qk;
	    struct[2] = Lk;
	    return struct;
	}
	
	/** Computes the projection of a function onto another basis.
	 * @param basisVectors the basis vectors
	 * @param f the function values on the vertices of the graph
	 * @return one matrix f on the basis vectors
	 */
	public static DoubleMatrix2D projectFunctionToBasis(DoubleMatrix2D basisVectors, DoubleMatrix2D f) {

		DoubleMatrix2D Qk = basisVectors;
		
		int numrowsf = f.rows();
		int numcolsf = f.columns();
		int numcolsQk = Qk.columns();
	    
	    // reconstruct the function at that resolution
		DoubleMatrix2D fk = basisVectors.like(numrowsf, numcolsf);
	    for (int col=0; col<numcolsf; col++) {
	    	
    		// get the col^th column of f
	    	DoubleMatrix1D f_col = ColtUtils.getcol(f,col);
	    	
	    	for (int i=0; i<numcolsQk; i++) {
	    		
	    		// get the ith column of Qk
	    		DoubleMatrix1D qi = ColtUtils.getcol(Qk,i);

	    		// add the projection of fi onto qi to fk
	            // Matlab code:  fk(:,col) = fk(:,col) + dot(f(:,col),qi)*qi;
	    		DoubleMatrix1D temp = ColtUtils.plus(ColtUtils.getcol(fk,col),
	    			ColtUtils.scale(qi,ColtUtils.dotproduct(f_col,qi)));
	    		ColtUtils.setcol(fk,col,temp);
	    	}
	    }

	    return fk;
	}
	
	
	public static void main(String[] args) {
		mainAssist(new double[][]{{1,2,3},{2,3,4},{3,4,5}});
		mainAssist(new double[][]{{1,2,3},{1,2,3},{1,2,3}});
		mainAssist(new double[][]{{1,0,1},{1,1,0},{1,1,0}});
		mainAssist(new double[][]{{1,1,0},{2,0,4},{1,0,0}});
		mainAssist(new double[][]{{1,0,1},{1,1,0},{0,0,0}});
	}
	
	public static void mainAssist(double[][] A) {
		
		Formatter formatter = new Formatter();
		
		DoubleMatrix2D AcoltD = DoubleFactory2D.sparse.make(A);
		Jama.Matrix    AjamaD = new Jama.Matrix(A);
		DoubleMatrix2D AcoltU = ColtUtils.mult(AcoltD, ColtUtils.transpose(AcoltD));
		Jama.Matrix    AjamaU = AjamaD.times(AjamaD.transpose());
		
		System.out.println("LapC(AcoltU) = "+formatter.toString(ColtSGTUtils.weightedAdjacencyToLaplacian(AcoltU, ColtSGTUtils.LaplacianType.COMBINATORIAL)));
		System.out.print("LapC(AjamaU) = ");SGTUtils.weightedAdjacencyToLaplacian(AjamaU, SGTUtils.LaplacianType.COMBINATORIAL).print(6,4);
		System.out.println("LapN(AcoltU) = "+formatter.toString(ColtSGTUtils.weightedAdjacencyToLaplacian(AcoltU, ColtSGTUtils.LaplacianType.NORMALIZED)));
		System.out.print("LapN(AjamaU) = ");SGTUtils.weightedAdjacencyToLaplacian(AjamaU, SGTUtils.LaplacianType.NORMALIZED).print(6, 4);
		System.out.println();
		System.out.println("LapC(AcoltD) = "+formatter.toString(ColtSGTUtils.weightedAdjacencyToLaplacian(AcoltD, ColtSGTUtils.LaplacianType.COMBINATORIAL)));
		System.out.print("LapC(AjamaD) = ");SGTUtils.weightedAdjacencyToLaplacian(AjamaD, SGTUtils.LaplacianType.COMBINATORIAL).print(6,4);
		System.out.println("LapN(AcoltD) = "+formatter.toString(ColtSGTUtils.weightedAdjacencyToLaplacian(AcoltD, ColtSGTUtils.LaplacianType.NORMALIZED)));
		System.out.print("LapN(AjamaD) = ");SGTUtils.weightedAdjacencyToLaplacian(AjamaD, SGTUtils.LaplacianType.NORMALIZED).print(6, 4);
		System.out.println();
		System.out.println();
		System.out.println();
	}

}
