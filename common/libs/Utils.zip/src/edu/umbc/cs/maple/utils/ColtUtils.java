package edu.umbc.cs.maple.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.matrix.DoubleFactory1D;
import cern.colt.matrix.DoubleFactory2D;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.doublealgo.Formatter;
import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.linalg.SingularValueDecomposition;
import cern.jet.math.Functions;
import cern.jet.math.Mult;
import optimization.Fmin;
import optimization.Fmin_methods;


/** Various utility functions for the COLT matrix library.
 * <p>
 * Copyright (c) 2008 Eric Eaton
 * <p>
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 * 
 * @author Eric Eaton (EricEaton@umbc.edu) <br>
 *         University of Maryland Baltimore County
 * 
 * @version 0.1
 *
 */
public class ColtUtils {

	/** Gets the specified column of a matrix.
	 * @param m the matrix.
	 * @param col the column to get.
	 * @return the specified column of m.
	 */
	public static DoubleMatrix1D getcol(DoubleMatrix2D m, int col) {
		return m.viewColumn(col);
	}
	
	
	/** Gets the specified columns of a matrix.
	 * @param m the matrix
	 * @param columns the columns to get
	 * @return the matrix of the specified columns of m.
	 */
	public static DoubleMatrix2D getcolumns(DoubleMatrix2D m, int[] columns) {
		DoubleMatrix2D colMatrix = m.like(m.rows(),columns.length);
		for (int i=0; i<columns.length; i++) {
			setcol(colMatrix, i, getcol(m, columns[i]));
		}
		return colMatrix;
	}
	
	
	/** Gets the specified row of a matrix.
	 * @param m the matrix.
	 * @param row the row to get.
	 * @return the specified row of m.
	 */
	public static DoubleMatrix1D getrow(DoubleMatrix2D m, int row) {
		return m.viewRow(row);
	}
	
	
	/** Gets the specified rows of a matrix.
	 * @param m the matrix
	 * @param rows the rows to get
	 * @return the matrix of the specified rows of m.
	 */
	public static DoubleMatrix2D getrows(DoubleMatrix2D m, int[] rows) {
		DoubleMatrix2D rowMatrix = m.like(rows.length, m.columns());
		for (int i=0; i<rows.length; i++) {
			setrow(rowMatrix, i, getrow(m, rows[i]));
		}
		return rowMatrix;
	}
	
	/** Sets the specified row of a matrix.  Modifies the passed matrix.
	 * @param m the matrix.
	 * @param row the row to modify.
	 * @param values the new values of the row.
	 */
	public static void setrow(DoubleMatrix2D m, int row, DoubleMatrix1D values) {
		m.viewRow(row).assign(values);
	}
	
	
	/** Sets the specified column of a matrix.  Modifies the passed matrix.
	 * @param m the matrix.
	 * @param col the column to modify.
	 * @param values the new values of the column.
	 */
	public static void setcol(DoubleMatrix2D m, int col, DoubleMatrix1D values) {
		m.viewColumn(col).assign(values);
	}
	
	
	/** Sets the specified column of a matrix.  Modifies the passed matrix.
	 * @param m the matrix.
	 * @param col the column to modify.
	 * @param values the new values of the column.
	 */
	public static void setcol(DoubleMatrix2D m, int col, double[] values) {
		if (values.length != m.rows())
			throw new IllegalArgumentException("values must have the same number of rows as the matrix.");
		for (int i=0; i<values.length; i++) {
			m.set(i, col, values[i]);
		}
	}
	
	
	/** Appends additional rows to the first matrix.
	 * @param m the first matrix.
	 * @param n the matrix to append containing additional rows.
	 * @return a matrix with all the rows of m then all the rows of n.
	 */
	public static DoubleMatrix2D rowAppend(DoubleMatrix2D m, DoubleMatrix2D n) {
		int mNumRows = m.rows();
		int mNumCols = m.columns();
		int nNumRows = n.rows();
		int nNumCols = n.columns();
		
		if (mNumCols != nNumCols)
			throw new IllegalArgumentException("Number of columns must be identical to row-append.");
		
		DoubleMatrix2D x = m.like(mNumRows+nNumRows,mNumCols);
		x.viewPart(0,mNumRows-1,0,mNumCols-1).assign(m);
		x.viewPart(mNumRows,mNumRows+nNumRows-1,0,mNumCols-1).assign(n);
		
		return x;
	}
	
	
	/** Appends additional columns to the first matrix.
	 * @param m the first matrix.
	 * @param n the matrix to append containing additional columns.
	 * @return a matrix with all the columns of m then all the columns of n.
	 */
	public static DoubleMatrix2D columnAppend(DoubleMatrix2D m, DoubleMatrix2D n) {
		int mNumRows = m.rows();
		int mNumCols = m.columns();
		int nNumRows = n.rows();
		int nNumCols = n.columns();
		
		if (mNumRows != nNumRows)
			throw new IllegalArgumentException("Number of rows must be identical to column-append.");
		
		DoubleMatrix2D x = m.like(mNumRows,mNumCols+nNumCols);
		x.viewPart(0,mNumRows-1,0,mNumCols-1).assign(m);
		x.viewPart(0,mNumRows-1,mNumCols,mNumCols+nNumCols-1).assign(n);
		
		return x;
	}
	
	
	/** Deletes a row from a matrix.  Does not change the passed matrix.
	 * @param m the matrix.
	 * @param row the row to delete.
	 * @return m with the specified row deleted.
	 */
	public static DoubleMatrix2D deleteRow(DoubleMatrix2D m, int row) {
		int numRows = m.rows();
		int numCols = m.columns();
		DoubleMatrix2D m2 = m.like(numRows-1,numCols);
		for (int mi=0,m2i=0; mi < numRows; mi++) {
			if (mi == row)
				continue;  // skips incrementing m2i
			setrow(m2,m2i,getrow(m,mi));
			m2i++;
		}
		return m2;
	}
	
	
	/** Deletes a column from a matrix.  Does not change the passed matrix.
	 * @param m the matrix.
	 * @param col the column to delete.
	 * @return m with the specified column deleted.
	 */
	public static DoubleMatrix2D deleteCol(DoubleMatrix2D m, int col) {
		int numRows = m.rows();
		int numCols = m.columns();
		DoubleMatrix2D m2 = m.like(numRows,numCols-1);
		for (int mj=0,m2j=0; mj < numCols; mj++) {
			if (mj == col)
				continue;  // skips incrementing m2j
			setcol(m2,m2j,getcol(m,mj));
			m2j++;
		}
		return m2;
	}
	
	
	/** Gets the sum of the specified row of the matrix.
	 * @param m the matrix.
	 * @param row the row.
	 * @return the sum of m[row,*]
	 */
	public static double rowsum(DoubleMatrix2D m, int row) {
		// error check the column index
		if (row < 0 || row >= m.rows()) {
			throw new IllegalArgumentException("row exceeds the row indices [0,"+(m.rows()-1)+"] for m.");
		}
		
		return ColtUtils.sum(getrow(m,row));
	}
	
	
	/** Gets the sum of the specified column of the matrix.
	 * @param m the matrix.
	 * @param col the column.
	 * @return the sum of m[*,col]
	 */
	public static double colsum(DoubleMatrix2D m, int col) {
		// error check the column index
		if (col < 0 || col >= m.columns()) {
			throw new IllegalArgumentException("col exceeds the column indices [0,"+(m.columns()-1)+"] for m.");
		}
		
		return ColtUtils.sum(getcol(m,col));
	}
	
	
	/** Computes the sum of each row of a matrix.
	 * @param m the matrix.
	 * @return a column vector of the sum of each row of m.
	 */
	public static DoubleMatrix1D rowsum(DoubleMatrix2D m) {
		int numRows = m.rows();
		DoubleMatrix1D sum = m.like1D(numRows);
		// loop through the rows and compute the sum
		for (int i=0; i<numRows; i++) {
			sum.set(i,rowsum(m,i));
		}
		return sum;
	}
	
	
	/** Computes the sum of each column of a matrix.
	 * @param m the matrix.
	 * @return a row vector of the sum of each column of m.
	 */
	public static DoubleMatrix1D colsum(DoubleMatrix2D m) {
		int numCols = m.columns();
		DoubleMatrix1D sum =  m.like1D(numCols);
		// loop through the rows and compute the sum
		for (int j=0; j<numCols; j++) {
			sum.set(j,colsum(m,j));
		}
		return sum;
	}

	
	
	/** Determines if a given matrix is a row vector, that is, it has only one row.
	 * @param m the matrix.
	 * @return whether the given matrix is a row vector (whether it has only one row).
	 */
	public static boolean isRowVector(DoubleMatrix2D m) {
		return m.rows()==1;
	}
	
	
	/** Determines if a given matrix is a column vector, that is, it has only one column.
	 * @param m the matrix.
	 * @return whether the given matrix is a column vector (whether it has only one column).
	 */
	public static boolean isColumnVector(DoubleMatrix2D m) {
		return m.columns()==1;
	}
	
	
	/** Transforms the given matrix into a column vector, that is, a matrix with one column.
	 * The matrix must be a vector (row or column) to begin with.
	 * @param m
	 * @return <code>m.transpose()</code> if m is a row vector,
	 *         <code>m</code> if m is a column vector.
	 * @throws IllegalArgumentException if m is not a row vector or a column vector.
	 */
	public static DoubleMatrix2D makeColumnVector(DoubleMatrix2D m) {	
		if (isColumnVector(m))
			return m;
		else if (isRowVector(m))
			return m_algebra.transpose(m);
		else
			throw new IllegalArgumentException("m is not a vector.");
	}
	
	
	/** Transforms the given matrix into a row vector, that is, a matrix with one row.
	 * The matrix must be a vector (row or column) to begin with.
	 * @param m
	 * @return <code>m.transpose()</code> if m is a column vector,
	 *         <code>m</code> if m is a row vector.
	 * @throws IllegalArgumentException if m is not a row vector or a column vector.
	 */
	public static DoubleMatrix2D makeRowVector(DoubleMatrix2D m) {
		if (isRowVector(m))
			return m;
		else if (isColumnVector(m))
			return m_algebra.transpose(m);
		else
			throw new IllegalArgumentException("m is not a vector.");
	}
	      
	
	/** Computes the dot product of two vectors.  Both must be either row or column vectors.
	 * @param m1
	 * @param m2
	 * @return the dot product of the two vectors.
	 */        
	public static double dotproduct(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		
		DoubleMatrix2D m1colVector = makeColumnVector(m1);
		DoubleMatrix2D m2colVector = makeColumnVector(m2);
		
		int n = m1colVector.rows();
		if (n != m2colVector.rows()) {
			throw new IllegalArgumentException("m1 and m2 must have the same number of elements.");
		}
		
		double scalarProduct = 0;
		for (int row=0; row<n; row++) {
			scalarProduct += m1colVector.get(row,0) * m2colVector.get(row,0);
		}
		
		return scalarProduct;
		
	}
	
	/** Computes the dot product of two vectors.  Both must be either row or column vectors.
	 * @param m1
	 * @param m2
	 * @return the dot product of the two vectors.
	 */    
	public static double dotproduct(DoubleMatrix1D m1, DoubleMatrix1D m2) {
	
		int n = m1.size();
		if (n != m2.size()) {
			throw new IllegalArgumentException("m1 and m2 must have the same number of elements.");
		}
		
		double scalarProduct = 0;
		for (int row=0; row<n; row++) {
			scalarProduct += m1.get(row) * m2.get(row);
		}
		
		return scalarProduct;
		
	}
	
	/** Determines whether a matrix is symmetric.
	 * @param m the matrix.
	 * @return <code>true</code> if a is symmetric, <code>false</code> otherwise
	 */
	public static boolean isSymmetric(DoubleMatrix2D m) {
		return m.equals(m_algebra.transpose(m));
	}
	
	
	public enum MaxMin {MAX, MIN, AVG};
	public static void makeMatrixSymmetric(DoubleMatrix2D m, MaxMin maxmin) {
		if (maxmin == MaxMin.MIN)
			m.assign(m_algebra.transpose(m), m_functions.min);
		else if (maxmin == MaxMin.MAX)
			m.assign(m_algebra.transpose(m), m_functions.max);
		else {
			ColtUtils.plusEquals(m, ColtUtils.transpose(m));
			ColtUtils.scale(m, 0.5);
			//m.assign(m_algebra.transpose(m), m_functions.plus);
			//m.assign(Mult.mult(0.5));
		}
	}
	
	
	/** Normalizes a matrix to make the elements sum to 1.
	 * @param m the matrix
	 * @return the normalized form of m with all elements summing to 1.
	 */
	public static DoubleMatrix2D normalize(DoubleMatrix2D m) {
		
		// compute the sum of the matrix
		double sum = sum(m);
		
		// normalize the matrix
		return scale(m.copy(), 1.0/sum);
	}
	
	
	public static double getMax(DoubleMatrix2D m) {
		return MathUtils.maxValue(ColtUtils.getNonZeros(m));
	}
	
	public static double getMin(DoubleMatrix2D m) {
		return MathUtils.minValue(ColtUtils.getNonZeros(m));
	}
	
	
	/** Make a matrix of ones.
	 * @param numRows the number of rows.
	 * @param numCols the number of columns.
	 * @return the numRows x numCols matrix of ones.
	 */
	public static DoubleMatrix2D ones(int numRows, int numCols) {
		return DoubleFactory2D.dense.make(numRows, numCols).assign(1);
	}
	
	/* Performs least squares regression using Tikhonov regularization.
	 * Solves the problem Ax = b for x using regularization:
	 *   min || Ax - b ||^2 - lambda^2 || x ||^2 ,  
	 * which can be solved by 
	 *   x = inv(A' * A + lambda^2 * I) * A' * b;
	 *   
	 * Uses the identity matrix as the regop, and estimates lambda using
	 * generalized cross-validation.
	 *
	 * @param A  the data matrix (n x m).
	 * @param b the target function values (n x 1).
	 */
	public static DoubleMatrix2D regLeastSquares(DoubleMatrix2D A, DoubleMatrix2D b) {

		int m = A.columns();
		int n = b.rows();

		// error check A and b
		if (A.rows() != n) {
			throw new IllegalArgumentException("A and b are incompatible sizes.");
		}
		
		// compute the optimal lambda using generalized cross-validation
	    double lambda = gcv(A, b);

		return regLeastSquares(A,b,lambda);
	}
	
	public static DoubleMatrix2D scale(DoubleMatrix2D m, double d) {
		DoubleMatrix2D mNew = m.copy();
		mNew.assign(Mult.mult(d));
		return mNew;
	}
	
	public static DoubleMatrix1D scale(DoubleMatrix1D m, double d) {
		DoubleMatrix1D mNew = m.copy();
		mNew.assign(Mult.mult(d));
		return mNew;
	}
	
	public static DoubleMatrix2D identity(int m) {
		return DoubleFactory2D.sparse.identity(m);
	}
	
	public static DoubleMatrix2D plus(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		return plusEquals(m1.copy(),m2);
	}
	
	public static DoubleMatrix2D plusEquals(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		m1.assign(m2,m_functions.plus);
		return m1;
	}
	
	public static DoubleMatrix1D plus(DoubleMatrix1D m1, DoubleMatrix1D m2) {
		return plusEquals(m1.copy(),m2);
	}
	
	public static DoubleMatrix1D plusEquals(DoubleMatrix1D m1, DoubleMatrix1D m2) {
		m1.assign(m2,m_functions.plus);
		return m1;
	}
	
	public static DoubleMatrix2D minus(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		return minusEquals(m1.copy(),m2);
	}
	
	public static DoubleMatrix2D minusEquals(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		m1.assign(m2,m_functions.minus);
		return m1;
	}
	
	public static DoubleMatrix1D minus(DoubleMatrix1D m1, DoubleMatrix1D m2) {
		return minusEquals(m1.copy(),m2);
	}
	
	public static DoubleMatrix1D minusEquals(DoubleMatrix1D m1, DoubleMatrix1D m2) {
		m1.assign(m2,m_functions.minus);
		return m1;
	}
	
	public static DoubleMatrix2D mult(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		return m_algebra.mult(m1, m2);
	}
	
	public static DoubleMatrix2D transpose(DoubleMatrix2D m) {
		return m_algebra.transpose(m).copy();
	}
	
	public static DoubleMatrix2D inverse(DoubleMatrix2D m) {
		return m_algebra.inverse(m).copy();
	}
	
	public static double normF(DoubleMatrix2D m) {
		return m_algebra.normF(m);
	}
	
	public static DoubleMatrix2D elementMultEquals(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		m1.assign(m2,m_functions.mult);
		return m1;
	}
	
	public static DoubleMatrix2D elementMult(DoubleMatrix2D m1, DoubleMatrix2D m2) {
		return elementMultEquals(m1.copy(),m2);
	}
	
	public static DoubleMatrix2D diagonalPow(DoubleMatrix2D m, double exponent) {
		DoubleMatrix1D diag = DoubleFactory2D.sparse.diagonal(m);
		diag.assign(m_functions.pow(exponent));
		int n = diag.size();
		if (exponent < 0) {
			for (int i=0; i<n; i++) {
				if (m.get(i,i)==0) // convention that 0^-1 = 0
				    diag.set(i, 0);
			}
		}
		return DoubleFactory2D.sparse.diagonal(diag);
	}
	
	public static DoubleMatrix1D to1D(DoubleMatrix2D m) {
		if (m.rows() == 1)
			return m.viewRow(0);
		if (m.columns() == 1)
			return m.viewColumn(0);
		throw new IllegalArgumentException("m is not one dimensional.");
	}
	
	public static DoubleMatrix2D to2D(DoubleMatrix1D m) {
		DoubleMatrix2D m2D = DoubleFactory2D.sparse.make(m.size(),1);
		setcol(m2D,0,m);
		return m2D;
	}
	
	static Functions m_functions = cern.jet.math.Functions.functions;
	static Algebra m_algebra = new Algebra();
	
	/* Performs least squares regression using Tikhonov regularization.
	 * Solves the problem Ax = b for x using regularization:
	 *   min || Ax - b ||^2 - lambda^2 || x ||^2 ,  
	 * which can be solved by 
	 *   x = inv(A' * A + lambda^2 * I) * A' * b;
	 *   
	 * Uses the identity matrix as the regularization operator.
	 *
	 * @param A  the data matrix (n x m).
	 * @param b the target function values (n x 1).
	 * @param lambda the lambda values.  If less than zero, it is estimated
	 *           using generalized cross-validation.
	 */
	public static DoubleMatrix2D regLeastSquares(DoubleMatrix2D A, DoubleMatrix2D b, double lambda) {
		int m = A.columns();
		Algebra algebra = new Algebra();
		DoubleMatrix2D regop = ColtUtils.scale(ColtUtils.identity(m),Math.pow(lambda,2));
		return regLeastSquares(A,b,regop);
	}
	
	/* Performs least squares regression using Tikhonov regularization.
	 * Solves the problem Ax = b for x using regularization:
	 *   min || Ax - b ||^2 - || \sqrt(regop) x ||^2 ,  
	 * which can be solved by 
	 *   x = inv(A' * A + regop) * A' * b;
	 *
	 * @param A  the data matrix (n x m).
	 * @param b the target function values (n x 1).
	 * @param regop the regularization operator (m x m). The default is to use the identity matrix
	 *              as the regularization operator, so you probably don't want to use this
	 *              verion of regLeastSquares() without a really good reason.  Use 
	 *              regLeastSquares(Matrix A, Matrix b, double lambda) instead.
	 */
	public static DoubleMatrix2D regLeastSquares(DoubleMatrix2D A, DoubleMatrix2D b, DoubleMatrix2D regop) {

		int m = A.columns();
		int n = b.rows();

		// error check A and b
		if (A.rows() != n) {
			throw new IllegalArgumentException("A and b are incompatible sizes.");
		}
		
		// error check A and regop
		if (regop.rows() != m || regop.columns() != m) {
			throw new IllegalArgumentException("A and regop are incompatible sizes.");
		}
		try {
		// solve the equation
		// x = inv(A' * A + regop) * A' * b;
		DoubleMatrix2D At = m_algebra.transpose(A).copy();
		DoubleMatrix2D AtA = m_algebra.mult(At,A);
		DoubleMatrix2D AtAplusRegop = ColtUtils.plusEquals(AtA,regop);
		DoubleMatrix2D AtAplusRegopInv = m_algebra.inverse(AtAplusRegop);
		DoubleMatrix2D AtB = m_algebra.mult(At,b);
		DoubleMatrix2D x = m_algebra.mult(AtAplusRegopInv, AtB);
		return x;
		}catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
			/*Formatter formatter = new Formatter();
			System.out.println("A:");
			System.out.println(formatter.toString(A));
			System.out.println("B:");
			System.out.println(formatter.toString(b));
			System.out.println("regop:");
			System.out.println(formatter.toString(regop));*/
			throw e;
		}
	}
	
	/* Selects the regularization parameter by generalized cross-validation.
	 *
	 *    Given a matrix A and a data vector b, it 
	 *    returns a regularization parameter rpar chosen by generalized
	 *    cross-validation using ridge regression.
	 *    
	 *                 RSS
	 *            G =  ---
	 *                 T^2
	 *
	 *    where T = n - sum(f_i) is an effective number of degrees of
	 *    freedom and f_i are the filter factors of the regularization
	 *    method.
	 *
	 *    The returned regularization parameter rpar is the ridge parameter of
	 *    ridge regression.
	 *
	 * References: 
	 *     Hansen, P. C., 1998: Rank-Deficient and Discrete Ill-Posed
	 *        Problems. SIAM Monogr. on Mathematical Modeling and
	 *        Computation, SIAM.
	 *
	 *     Wahba, G., 1990: Spline Models for Observational Data. CBMS-NSF
	 *        Regional Conference Series in Applied Mathematics, Vol. 59,
	 *        SIAM.
	 *
	 *     Adapted from various routines in Per-Christian Hansen's
	 *     regularization toolbox for matlab, then converted to java. 
	 */
	protected static double gcv(DoubleMatrix2D A, DoubleMatrix2D b) {
		
		int AnumRows = A.rows();
		int AnumCols = A.columns();
		
		// SVD of A
		DoubleMatrix2D U = null;
		double[] s = null;
		if (AnumRows >= AnumCols) {  // AnumRows >= AnumCols so Jama SVD will work
			SingularValueDecomposition Asvd = new SingularValueDecomposition(A);  // Jama SVD computes the economy SVD
			U = Asvd.getU();
			s = Asvd.getSingularValues();
		} 
		// AnumRows < AnumCols, so Jama SVD won't work without adjustment
		// Using [U,S,V] = svd(A)  <===>  [V,S,U] = svd(A')
		else {	
			SingularValueDecomposition Asvd = new SingularValueDecomposition(m_algebra.transpose(A));
			U = Asvd.getV();
			s = Asvd.getSingularValues();
		}

		int n = U.rows();
		int q = U.columns();
		
		U = U.copy();
		DoubleMatrix2D Ut = m_algebra.transpose(U.copy());

		// Coefficients in expansion of solution in terms of right singular vectors
		// fc = U(:, 1:q)'*g;
		DoubleMatrix2D fc = m_algebra.mult(Ut, b);
		// s2 = s.^2;
		double[] s2 = new double[q];
		for (int i=0; i<q; i++) {
			s2[i] = Math.pow(s[i],2);
		}
		  
		// Least squares residual 
		double rss0 = 0;
		if (n > q) {  
			// rss0 = sum((g - U(:, 1:q)*fc).^2);
			DoubleMatrix2D tempValues = ColtUtils.minus(b,m_algebra.mult(U,fc));
			double[] values = ColtUtils.getNonZeros(tempValues);
			for (double d : values) {
				rss0 += Math.pow(d,2);
			}
		}

		// Accuracy of regularization parameter 
		// h_tol = ((q^2 + q + 1)*eps)^(1/2);
		double eps = Math.pow(2,-52);
		double h_tol = Math.sqrt((Math.pow(q,2) + q + 1)*eps);        
		    
		// Heuristic upper bound on regularization parameter
		// h_max = max(s);
		double h_max = MathUtils.maxValue(s);

		// Heuristic lower bound
		// h_min = min(s) * h_tol;
		double h_min = MathUtils.minValue(s) * h_tol;
		  
		    
		// Find minimizer of GCV function
		// minopt = optimset('TolX', h_tol, 'Display', 'off');
		// [rpar, G] = fminbnd('gcvfctn', h_min, h_max, minopt, s2, fc, rss0, n-q); 
		GCVFn gcvfn = new ColtUtils.GCVFn();
		gcvfn.setS2(s2);
		gcvfn.setFC(fc);
		gcvfn.setRSS0(rss0);
		gcvfn.setDOF0(n-q);
		
		/*
		System.out.println("Doing Fmin with:");
		System.out.print("  s2 = [ "); for (double d:s2) System.out.print(d + " "); System.out.println("]");
		System.out.print("  fc = "); fc.print(6,4);
		System.out.println("  rss0 = " + rss0);
		System.out.println("  dof0 = " + (n-q));
		*/
		
		double rpar = Fmin.fmin(h_min, h_max, gcvfn, h_tol);
		
		return rpar;

	}
	
	private static class GCVFn implements Fmin_methods {
		
		double[] s2;
		DoubleMatrix2D fc;
		double rss0;
		double dof0;
		
		public void setS2(double[] s2)   { this.s2 = s2; }
		public void setFC(DoubleMatrix2D fc)     { this.fc = fc; }
		public void setRSS0(double rss0) { this.rss0 = rss0; }
		public void setDOF0(double dof0) { this.dof0 = dof0; }

		public double f_to_minimize(double lambda) {
			try {
			if (fc.rows() > s2.length) {
				throw new IllegalStateException("Not enough s2's:  fc.numRows() > s2.length");
			}
			// f = lambda^2 ./ (s2 + lambda^2);
			double lambda2 = Math.pow(lambda, 2);
			int rows = fc.rows();
			DoubleMatrix2D f = fc.like(rows,1);
			for (int i=0; i<rows; i++) {
				double val = lambda2 / (s2[i] + lambda2);
				f.set(i,0,val);
			}

			// G = (norm(f.*fc)^2 + rss0) / (dof0 + sum(f))^2;
			double denominator = Math.pow(dof0 + sum(f),2);
			f = elementMultEquals(f,fc);
			double numerator = Math.pow(m_algebra.norm2(f),2) + rss0;
			
			return numerator / denominator;
			} catch(Exception e) {
				System.exit(1);
			}
			return 0;
		}
		
	}
	
	
	public static double rmse(DoubleMatrix2D a, DoubleMatrix2D b) {
		DoubleMatrix2D difference = ColtUtils.minus(a,b);
		DoubleMatrix2D temp = m_algebra.mult(m_algebra.transpose(difference), difference);
        double rmse = Math.sqrt(ColtUtils.sum(temp));
        return rmse;
	}
	
	public static double[] getNonZeros(DoubleMatrix2D m) {
		IntArrayList rowList = new IntArrayList();
		IntArrayList colList = new IntArrayList();
        DoubleArrayList valueList = new DoubleArrayList();
		m.getNonZeros(rowList, colList, valueList);
		return JavaUtils.collectionToPrimitiveArray((ArrayList<Double>)valueList.toList());
	}
	
	public static double[] getNonZeros(DoubleMatrix1D m) {
		IntArrayList rowList = new IntArrayList();
        DoubleArrayList valueList = new DoubleArrayList();
		m.getNonZeros(rowList, valueList);
		return JavaUtils.collectionToPrimitiveArray((ArrayList<Double>)valueList.toList());
	}
	
	public static double sum(DoubleMatrix2D m) {
		return MathUtils.sum(getNonZeros(m));
	}
	
	public static double sum(DoubleMatrix1D m) {
		return MathUtils.sum(getNonZeros(m));
	}
	
	
	public static DoubleMatrix2D loadDoubleMatrix2D(File file) {
		FileReader fileReader = null;
		try {
			
			fileReader = new FileReader(file);
			BufferedReader reader = new BufferedReader(fileReader);
			int lineNumber = 0;
			String line = null;
			String[] split = null;
			int rows=-1, cols=-1;
			
			// read the matrix size
			while ((line = reader.readLine()) != null) {
				lineNumber++;
				
				// skip lines that don't start with a number
				if (!line.matches("^\\d+?.*"))
					continue;
				
				split = line.split("[\\s,;]");
				
				if (split.length != 2) {
					throw new IllegalArgumentException("Invalid matrix file format:  file must start with the size of the matrix.  Error on line number "+lineNumber+".");
				}
				
				rows = Integer.parseInt(split[0]);
				cols = Integer.parseInt(split[1]);
				break;
			}
				
			DoubleMatrix2D matrix = DoubleFactory2D.sparse.make(rows,cols);
			int row = 0;
			
			// read each line of the matrix, skipping non-matrix rows
			while ((line = reader.readLine()) != null) {
				lineNumber++;
				
				// skip lines that don't start with a number
				if (!line.matches("^\\d+?.*"))
					continue;
				
				split = line.split("[\\s,;]");
				// detect a full matrix specification
				if (split.length == cols) {
					for (int col=0; col<cols; col++) {
						matrix.set(row, col, Double.parseDouble(split[col]));
					}
				} else if (split.length == 3) {
					matrix.set(Integer.parseInt(split[0]), 
							   Integer.parseInt(split[1]), 
							   Double.parseDouble(split[2]));
				} else {
					throw new IllegalArgumentException("Invalid matrix file format:  must be either a full or sparse specification.  Error on line number "+lineNumber+".");
				}
				row++;
			}
			
			return matrix;
			
		} catch (IOException e) {
			System.err.println("Invalid file:  "+file.getAbsolutePath());
		} finally {
			try {
				fileReader.close();
			} catch (Exception e) {}
		}
		
		return null;
	}
	
	public static void printSparseMatrix(PrintStream outStream, DoubleMatrix2D m) {
		
		outStream.println(m.rows()+","+m.columns());
		
		IntArrayList rows = new IntArrayList();
		IntArrayList cols = new IntArrayList();
		DoubleArrayList values = new DoubleArrayList();
		m.getNonZeros(rows, cols, values);
		
		if (rows.size() != cols.size() && rows.size() != values.size()) {
			System.out.println("Sizes of getNonZeros() args don't match");
			System.exit(-1);
		}
		
		int numUniqueVals = rows.size();
		for (int i=0; i<numUniqueVals; i++) {
			outStream.println(rows.get(i)+","+cols.get(i)+","+values.get(i));
		}
	}
	
	
	public static void main(String[] args) {
		
		Formatter formatter = new Formatter();
		
		DoubleMatrix2D A = DoubleFactory2D.sparse.make(new double[][]{{1,2,3},{4,5,6},{7,8,10}});
		DoubleMatrix2D b = DoubleFactory2D.sparse.make(new double[][]{{0.5},{0.7},{0.8}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [-0.2405; 0.1480; 0.1368] with lambda = 0.41424");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.1:");
		System.out.println("  Should be [-0.4192; 0.5114; -0.0342]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.1)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.5:");
		System.out.println("  Should be [-0.2120; 0.1180; 0.1416]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.5)));
		
		System.out.println("Solving Ax = b for x with lambda = 1:");
		System.out.println("  Should be [-0.1007; 0.0593; 0.1136]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,1)));
		
		
		A = DoubleFactory2D.sparse.make(new double[][]{{1,.2,.36},{1,.55,.65},{1,.8,.41}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.25},{0.17},{0.98}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.2180; 0.2234; 0.0565] with lambda = 1.2105");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.1:");
		System.out.println("  Should be [0.5278; 1.2681; -1.5171]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.1)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.5:");
		System.out.println("  Should be [0.2347; 0.5517; -0.1535]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.5)));
		
		System.out.println("Solving Ax = b for x with lambda = 1:");
		System.out.println("  Should be [0.2301; 0.2726; 0.0401]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,1)));
		
		

		A = DoubleFactory2D.sparse.make(new double[][]{{1,2,3},{4,5,6},{7,8,9},{10,11,12},{13,14,15}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.5},{0.7},{0.8},{0.3},{0.4}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [-0.3250; -0.0047; 0.3156] with lambda = 0.45081");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.1:");
		System.out.println("  Should be [-0.3550; -0.0066; 0.3418]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.1)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.5:");
		System.out.println("  Should be [-0.3185; -0.0043; 0.3098]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.5)));
		
		System.out.println("Solving Ax = b for x with lambda = 1:");
		System.out.println("  Should be [-0.2400; 0.0005; 0.2409]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,1)));
		
		
		A = DoubleFactory2D.sparse.make(new double[][]{{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.5},{0.7},{0.8}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [-0.0779; -0.0359; 0.0061; 0.0481; 0.0902] with lambda = 0.31315");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.1:");
		System.out.println("  Should be [-0.0792; -0.0366; 0.0060; 0.0486; 0.0912]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.1)));
		
		System.out.println("Solving Ax = b for x with lambda = 0.5:");
		System.out.println("  Should be [-0.0758; -0.0347; 0.0063; 0.0474; 0.0884]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,0.5)));
		
		System.out.println("Solving Ax = b for x with lambda = 1:");
		System.out.println("  Should be [-0.0665; -0.0297; 0.0072; 0.0440; 0.0808]");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b,1)));
		
		System.out.println();
		System.out.println("===============================================");
		System.out.println();
		

		A = DoubleFactory2D.sparse.make(new double[][]{{2.2,-4.3,5.4,1.2,4.8},{2.2,2.3,7.8,3.4,5.3}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.2},{0.4}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.0055; 0.0145; 0.0266; 0.0094; 0.0172] with lambda = 2.1381e-007");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		A = DoubleFactory2D.sparse.make(new double[][]{{1,2,3,4,5,6,7},{1,7,6,5,4,3,2},{1,2,4,6,8,10,3}});
		b = DoubleFactory2D.sparse.make(new double[][]{{1},{2},{7}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.0130; 0.0235; 0.0602; 0.0969; 0.1336; 0.1703; 0.0032] with lambda = 12.1354");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));

		
		A = DoubleFactory2D.sparse.make(new double[][]{{.211,.485,.5893,-.1,.1,-.342,.8,.19,-.20,-.91},{.211,-.2,.2,.48,.9,.94,-.28,.7,.39,.1},{.211,-.38,.85,.2,-.38,.19,-.1,0,-.48,.23}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.98},{0.47},{0.86}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.0989; 0.0017; 0.2891; 0.0632; 0.0311; 0.0583; 0.1062; 0.1008; -0.0915; -0.1193] with lambda = 1.7534");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		

		A = DoubleFactory2D.sparse.make(new double[][]{{.211,.485,.5893},{-.1,.1,-.342},{.8,.19,-.20},{.211,-.2,.2},{.48,.9,.94},{-.28,.7,.39},{.211,-.38,.85},{.2,-.38,.19},{-.1,0,-.48}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.15},{0.7},{0.8},{0.5},{-0.7},{0.1},{0.45},{-0.7},{-0.8}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.0910; -0.0500; -0.0350] with lambda = 1.8448");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
		
		
		A = DoubleFactory2D.sparse.make(new double[][]{{1,-2,3},{-4,5,6},{7,8,-9},{-10,11,12},{13,-14,-15}});
		b = DoubleFactory2D.sparse.make(new double[][]{{0.5},{-0.7},{0.8},{0.3},{-0.4}});
		System.out.println("A = "+formatter.toString(A));
		System.out.println("b = "+formatter.toString(b));
		
		System.out.println("Solving Ax = b for x:");
		System.out.println("  Should be [0.0016;0.0079;-0.0013] with lambda = 32.5251");
		System.out.println(formatter.toString(ColtUtils.regLeastSquares(A,b)));
	}
}
