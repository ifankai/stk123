package com.github.promeg.tinypinyin.lexicons.android.cncity;

import android.app.Application;

/**
 * Created by piasy on 15/4/14.
 */
public class TestApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
