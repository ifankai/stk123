({
  title: function () {
    return 'Welcome';
  },
  again: 'Goodbye'
});
