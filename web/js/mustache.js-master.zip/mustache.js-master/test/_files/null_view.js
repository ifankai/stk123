({
  name: 'Joe',
  friends: null
});
