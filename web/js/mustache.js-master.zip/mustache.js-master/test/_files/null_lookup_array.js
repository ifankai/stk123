({
  'name': 'David',
  'twitter': '@dasilvacontin',
  'farray': [
    ['Flor', '@florrts'],
    ['Miquel', null],
    ['Chris', undefined]
  ]
});
