Spring Mobile 2.0.0.M3
-----------------------------------------------------------
The Spring Mobile project provides support for developing cross-platform mobile 
web applications. It contains extensions to Spring MVC that aim to simplify mobile 
application development.

Please consult the documentation located within the 'docs/reference' directory
of this release and also visit the official Spring Mobile home at:
http://projects.spring.io/spring-mobile/

There you will find links to the issue tracker, samples, and other resources.